<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h2>Requests</h2>
            <div class="table-responsive mt-3">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Reference No</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Name as IC</th>
                            <th>IC</th>
                            <th>Phone Number</th>
                            <th>Address</th>
                            <th>Bank</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Amount</th>
                            <th>DateTime</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>                           
                            <tr>
                                <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                <td><?php echo e($item->reference_no); ?></td>
                                <td><?php echo e($item->price); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td><?php echo e($item->name_as_ic); ?></td>
                                <td><?php echo e($item->ic); ?></td>
                                <td><?php echo e($item->phone_number); ?></td>
                                <td><?php echo e($item->address); ?></td>
                                <td><?php echo e($item->bank->name ?? ''); ?></td>
                                <td><?php echo e($item->username); ?></td>
                                <td><?php echo e($item->password); ?></td>
                                <td><?php echo e($item->amount); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <tr>
                               <td colspan="20" align="center">No Data</td>
                           </tr>
                       <?php endif; ?>
                    </tbody>
                </table>                
                <div class="clearfix mt-2">
                    <div class="float-left" style="margin: 0;">
                        <p>Total <strong style="color: red"><?php echo e($data->total()); ?></strong> Items</p>
                    </div>
                    <div class="float-right" style="margin: 0;">
                        <?php echo $data->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Mooboo\homecare\resources\views/home.blade.php ENDPATH**/ ?>